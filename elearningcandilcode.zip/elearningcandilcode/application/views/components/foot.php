<!--Footer-part-->

<div class="row-fluid">
	<div id="footer" class="span12"> 2019 &copy; Pembelajaran Online <a
			href="home">STMIK IBBI</a> - Design by Al azmi</div>
</div>

<!--end-Footer-part-->
